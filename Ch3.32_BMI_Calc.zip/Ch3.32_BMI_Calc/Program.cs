﻿using System;
using System.Collections;
using System.Linq;
using System.Text;

namespace BMI_Calc
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your weight in pounds: ");
            double lb = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter your height in inches: ");
            double inch = Convert.ToDouble(Console.ReadLine());

            double bmi_total = (lb*703) / (inch * inch);
            Console.WriteLine("Your BMI is " + bmi_total);

            if (bmi_total < 18.5)
                Console.WriteLine("You are underweight.");

            else if (bmi_total > 18.5 && bmi_total < 24.9)
                Console.WriteLine("You are an ideal weight.");


            else if (bmi_total > 25 && bmi_total < 29.9)
                Console.WriteLine("You are overweight.");

            else if (bmi_total > 30)
                Console.WriteLine("You are obese.");


        }
    }
}