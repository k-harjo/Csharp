﻿using System;

class Program
{
    static void Main()
    {
        // prompt user to enter name and year of birth

        Console.WriteLine($"Please enter the user's first name: ");
        var firstName = Console.ReadLine();

        Console.WriteLine($"Please enter the user's last name:");
        var lastName = Console.ReadLine();

        Console.WriteLine($"Please enter the user's year of birth: ");
        var yearOfBirth = Convert.ToInt32(Console.ReadLine());

        var heartRate = new HeartRates(firstName, lastName, yearOfBirth);

        Console.WriteLine("Name of user: {0} {1}", heartRate.FirstName, heartRate.LastName);
        Console.WriteLine("Age of user: {0}", heartRate.PersonsAge);
        Console.WriteLine("User's maximum safe heart rate: {0} bpm", heartRate.MaxHeartRate);
        Console.WriteLine("User's target heart rate range: {0} bpm - {1} bpm", heartRate.MinTargetRate, heartRate.MaxTargetRate);
    }

}
class HeartRates
    {
        private string _firstName;
        private string _lastName;
        private int _yearOfbirth;

        public HeartRates(string firstName, string lastName, int yearOfBirth)
        {
            // obtain current year
            CurrentYear = DateTime.Today.Year;
            // assign values passed into constructor
            FirstName = firstName;
            LastName = lastName;
            YearOfBirth = yearOfBirth;
        }

        // assign first name
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value == "" ? "n/a" : value; }
        }

        // assign first name
        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value == "" ? "n/a" : value; }
        }

        public int YearOfBirth
        {
            get { return _yearOfbirth; }
            set { _yearOfbirth = value < 1 ? 0 : value; }
        }

        public readonly int CurrentYear;

            public int PersonsAge
        {
            get { return Convert.ToInt32(CurrentYear - YearOfBirth); }
        }

        public int MaxHeartRate
        {
            get { return 220 - PersonsAge; }
        }

        public int MinTargetRate
        {
            get { return Convert.ToInt32(MaxHeartRate * 0.5); }
        }


        public int MaxTargetRate
        {
            get { return Convert.ToInt32(MaxHeartRate * 0.85); }
        }

    }
