﻿using System;
using System.Collections;
using System.Linq;
using System.Text;

namespace Carpool_Calc
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of miles you drive to work daily: ");
            double miles_driven = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the current cost of gasoline per gallon in cents: ");
            double gas_cost = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the average number of miles your car drives per gallon: ");
            double mpg = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("If you pay parking fees, please enter the total here in cents: ");
            double parking = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("If you pay tolls, please enter the total here in cents: ");
            double tolls = Convert.ToDouble(Console.ReadLine());


            double driving_total = (miles_driven / mpg) * gas_cost;
            Console.WriteLine("Total gas cost: " + driving_total);

            if (parking >= 0)
                parking = parking + driving_total;
                Console.WriteLine("Gas cost with parking: " + parking);

            if (tolls >= 0)
                tolls = tolls + driving_total;
                Console.WriteLine("Gas cost with tolls: " + tolls);

            double weekly_total = driving_total + parking + tolls;
            Console.WriteLine("Your weekly trip total is: " + weekly_total);

            double one_p = weekly_total / 2;
            double two_p = weekly_total / 3;
            double three_p = weekly_total / 4;
            double four_p = weekly_total / 5;


            Console.WriteLine("If you carpool and split the cost your total would be:");
            Console.WriteLine("Carpool with one person: " + one_p);
            Console.WriteLine("Carpool with one person: " + two_p);
            Console.WriteLine("Carpool with one person: " + three_p);
            Console.WriteLine("Carpool with one person: " + four_p);
        }
    }
}